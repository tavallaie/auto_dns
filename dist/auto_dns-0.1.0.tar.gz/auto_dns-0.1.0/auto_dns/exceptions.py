class UnsupportedProviderError(Exception):
    """Exception raised for unsupported DNS providers."""

    pass
