# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['auto_ddns', 'auto_ddns.dns_providers']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0.1,<7.0.0', 'requests>=2.31.0,<3.0.0', 'typer>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['AutoDDNS = auto_ddns:app']}

setup_kwargs = {
    'name': 'auto-ddns',
    'version': '0.1.0',
    'description': 'A DDNS Python Library.',
    'long_description': '',
    'author': 'Ali Tavallaie',
    'author_email': 'a.tavallaie@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
